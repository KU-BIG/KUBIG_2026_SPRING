"""
HAN baseline + HAN-with-EPD-features for hetero node classification.

Both models accept a `target_node` arg so the same code works on DBLP (author),
IMDB (movie), ACM (paper), etc.
"""

from typing import Dict
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import HANConv


class HANBase(nn.Module):
    def __init__(self,
                 in_channels_dict: Dict[str, int],
                 hidden_channels: int,
                 out_channels: int,
                 metadata,
                 target_node: str = "author",
                 heads: int = 8,
                 dropout: float = 0.5):
        super().__init__()
        self.target_node = target_node
        self.han = HANConv(in_channels_dict, hidden_channels,
                            heads=heads, metadata=metadata, dropout=dropout)
        self.dropout = dropout
        self.classifier = nn.Linear(hidden_channels, out_channels)

    def encode(self, x_dict, edge_index_dict):
        h = self.han(x_dict, edge_index_dict)
        return h[self.target_node]

    def forward(self, x_dict, edge_index_dict):
        z = self.encode(x_dict, edge_index_dict)
        z = F.dropout(z, p=self.dropout, training=self.training)
        return self.classifier(z)


class HANWithEPD(nn.Module):
    def __init__(self,
                 in_channels_dict: Dict[str, int],
                 hidden_channels: int,
                 out_channels: int,
                 epd_dim: int,
                 metadata,
                 target_node: str = "author",
                 heads: int = 8,
                 dropout: float = 0.5,
                 epd_hidden: int = 64):
        super().__init__()
        self.target_node = target_node
        self.han = HANConv(in_channels_dict, hidden_channels,
                            heads=heads, metadata=metadata, dropout=dropout)
        self.epd_proj = nn.Sequential(
            nn.Linear(epd_dim, epd_hidden),
            nn.ReLU(),
            nn.Linear(epd_hidden, epd_hidden),
        )
        self.dropout = dropout
        self.classifier = nn.Linear(hidden_channels + epd_hidden, out_channels)

    def forward(self, x_dict, edge_index_dict, epd_features: torch.Tensor):
        h = self.han(x_dict, edge_index_dict)[self.target_node]
        e = self.epd_proj(epd_features)
        z = torch.cat([h, e], dim=-1)
        z = F.dropout(z, p=self.dropout, training=self.training)
        return self.classifier(z)
