"""
Colab Setup Cell — run once per session before importing anything else.

Usage in Colab:
  - Upload /Users/.../tda-conference/hetero_pdgnn/* to Colab (or git clone your repo)
  - Upload dgformat.py and riccidist2dgm.py patches to /content/
  - Run the cells below in order
"""

# %% [setup] Install TLC-GNN and dependencies
"""
Run these as separate Colab cells (start with !):

!git clone https://github.com/pkuyzy/TLC-GNN.git
%cd /content/TLC-GNN

import torch
v = torch.__version__.split('+')[0]
cuda = 'cu' + torch.version.cuda.replace('.', '') if torch.cuda.is_available() else 'cpu'
!pip install torch-scatter torch-sparse -f https://data.pyg.org/whl/torch-{v}+{cuda}.html -q
!pip install torch-geometric gudhi networkx scikit-learn -q

# Apply patches (dgformat.py + riccidist2dgm.py uploaded to /content/)
import shutil
shutil.copy('/content/dgformat.py', '/content/TLC-GNN/sg2dgm/dgformat.py')
shutil.copy('/content/riccidist2dgm.py', '/content/TLC-GNN/sg2dgm/riccidist2dgm.py')

# Build the persistence imager extension (or fallback to .py)
%cd /content/TLC-GNN/sg2dgm
!python setup_PI.py build_ext --inplace || cp persistenceImager.pyx persistenceImager.py
%cd /content/TLC-GNN
print('Setup complete.')
"""
