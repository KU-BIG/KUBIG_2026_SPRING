"""
Train / evaluate HANBase and HANWithEPD on hetero node classification.

Dataset-agnostic: target_node is parameterized.
"""

from typing import Dict, List, Optional
import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import f1_score

from .models import HANBase, HANWithEPD


def _macro_f1(logits: torch.Tensor, y: torch.Tensor, mask: torch.Tensor) -> float:
    pred = logits.argmax(dim=-1)[mask].cpu().numpy()
    true = y[mask].cpu().numpy()
    return f1_score(true, pred, average="macro")


def _set_seed(seed: int):
    import random
    random.seed(seed); np.random.seed(seed)
    torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)


def _get_target_masks(data, target_node: str):
    """Pull (y, train_mask, val_mask, test_mask) from data[target_node]."""
    node = data[target_node]
    return node.y, node.train_mask, node.val_mask, node.test_mask


def train_one(data,
              model: torch.nn.Module,
              epd_feat: Optional[torch.Tensor] = None,
              *,
              target_node: str = "author",
              lr: float = 5e-3,
              weight_decay: float = 1e-3,
              epochs: int = 200,
              patience: int = 30,
              device: str = "cpu",
              verbose: bool = False) -> Dict[str, float]:
    data = data.to(device)
    model = model.to(device)
    if epd_feat is not None:
        epd_feat = epd_feat.to(device)

    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)

    y, train_mask, val_mask, test_mask = _get_target_masks(data, target_node)

    best_val = -1.0
    best = {"train": 0.0, "val": 0.0, "test": 0.0, "epoch": 0}
    bad = 0

    for epoch in range(1, epochs + 1):
        model.train()
        opt.zero_grad()
        if epd_feat is None:
            out = model(data.x_dict, data.edge_index_dict)
        else:
            out = model(data.x_dict, data.edge_index_dict, epd_feat)
        loss = F.cross_entropy(out[train_mask], y[train_mask])
        loss.backward()
        opt.step()

        model.eval()
        with torch.no_grad():
            if epd_feat is None:
                out = model(data.x_dict, data.edge_index_dict)
            else:
                out = model(data.x_dict, data.edge_index_dict, epd_feat)
            tr = _macro_f1(out, y, train_mask)
            va = _macro_f1(out, y, val_mask)
            te = _macro_f1(out, y, test_mask)

        if va > best_val:
            best_val = va
            best = {"train": tr, "val": va, "test": te, "epoch": epoch}
            bad = 0
        else:
            bad += 1
            if bad >= patience:
                break

        if verbose and epoch % 20 == 0:
            print(f"  ep {epoch:3d}  loss {loss.item():.3f}  "
                  f"train {tr:.3f}  val {va:.3f}  test {te:.3f}")

    return best


def compare(data,
            epd_feat: torch.Tensor,
            *,
            target_node: str = "author",
            hidden_channels: int = 64,
            heads: int = 8,
            seeds: List[int] = (0, 1, 2, 3, 4),
            device: str = "cpu",
            verbose: bool = True) -> Dict[str, Dict[str, float]]:
    """Train both HANBase and HANWithEPD across seeds; return mean ± std test F1."""
    in_channels_dict = {nt: data[nt].x.size(-1) for nt in data.node_types}
    y = data[target_node].y
    out_channels = int(y.max().item()) + 1
    metadata = data.metadata()
    epd_dim = epd_feat.size(-1)

    results = {"HAN": [], "HAN+EPD": []}

    for seed in seeds:
        _set_seed(seed)
        if verbose:
            print(f"\n=== seed {seed}  HAN baseline ===")
        base = HANBase(in_channels_dict, hidden_channels, out_channels,
                       metadata=metadata, target_node=target_node, heads=heads)
        r_base = train_one(data, base, None,
                            target_node=target_node, device=device, verbose=verbose)
        results["HAN"].append(r_base["test"])
        if verbose:
            print(f"  -> best ep {r_base['epoch']}  test F1 {r_base['test']:.4f}")

        _set_seed(seed)
        if verbose:
            print(f"=== seed {seed}  HAN + EPD ===")
        epd_model = HANWithEPD(in_channels_dict, hidden_channels, out_channels,
                                epd_dim=epd_dim, metadata=metadata,
                                target_node=target_node, heads=heads)
        r_epd = train_one(data, epd_model, epd_feat,
                           target_node=target_node, device=device, verbose=verbose)
        results["HAN+EPD"].append(r_epd["test"])
        if verbose:
            print(f"  -> best ep {r_epd['epoch']}  test F1 {r_epd['test']:.4f}")

    summary = {}
    for name, scores in results.items():
        scores = np.array(scores)
        summary[name] = {"mean": float(scores.mean()),
                          "std":  float(scores.std()),
                          "all":  scores.tolist()}
    return summary
