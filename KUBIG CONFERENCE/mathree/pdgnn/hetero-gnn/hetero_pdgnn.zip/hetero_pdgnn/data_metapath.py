"""
DBLP loader + meta-path subgraph builder (dataset-agnostic version).

NOTE: kept the original DBLP-specific symbols (AUTHOR_METAPATHS, load_dblp,
build_author_subgraphs, add_metapath_edges_to_data) as thin shims that delegate
to the generic implementations, so previously-written Colab cells still work.

For a new dataset, just use:
    from hetero_pdgnn.datasets import get_config
    cfg = get_config("IMDB")
    data = cfg.loader()
    subs = build_target_subgraphs(data, cfg, k_knn=cfg.knn_k)
"""

import torch
import numpy as np
import networkx as nx
import scipy.sparse as sp
from typing import Dict, List, Tuple, Optional

from .datasets import DatasetConfig, get_config


# ----------------------------------------------------------------------------
# Generic meta-path adjacency
# ----------------------------------------------------------------------------
def _edge_index_to_csr(edge_index: torch.Tensor,
                        n_rows: int, n_cols: int) -> sp.csr_matrix:
    row = edge_index[0].cpu().numpy()
    col = edge_index[1].cpu().numpy()
    vals = np.ones(row.shape[0], dtype=np.float32)
    return sp.csr_matrix((vals, (row, col)), shape=(n_rows, n_cols))


def metapath_adjacency(data, metapath: List[Tuple[str, str, str]]) -> sp.csr_matrix:
    """A_1 @ A_2 @ ... along the meta-path. Entry = number of meta-paths."""
    num_nodes = {nt: data[nt].num_nodes for nt in data.node_types}
    A = None
    for etype in metapath:
        src, _, dst = etype
        ei = data[etype].edge_index
        a = _edge_index_to_csr(ei, num_nodes[src], num_nodes[dst])
        A = a if A is None else A @ a
    return A


# ----------------------------------------------------------------------------
# k-NN sparsification
# ----------------------------------------------------------------------------
def knn_sparsify(A: sp.csr_matrix, k: int) -> sp.csr_matrix:
    """Keep top-k entries per row (by value, diagonal excluded). Vectorized."""
    A = A.tocsr().copy()
    A.setdiag(0)
    A.eliminate_zeros()

    new_data, new_indices, new_indptr = [], [], [0]
    for i in range(A.shape[0]):
        s, e = A.indptr[i], A.indptr[i+1]
        vals = A.data[s:e]
        cols = A.indices[s:e]
        if len(vals) <= k:
            new_data.append(vals); new_indices.append(cols)
        else:
            top = np.argpartition(-vals, k)[:k]
            new_data.append(vals[top]); new_indices.append(cols[top])
        new_indptr.append(new_indptr[-1] + len(new_data[-1]))
    return sp.csr_matrix(
        (np.concatenate(new_data), np.concatenate(new_indices), np.array(new_indptr)),
        shape=A.shape,
    )


# ----------------------------------------------------------------------------
# Subgraph builders (generic)
# ----------------------------------------------------------------------------
def metapath_subgraph_nx(data,
                          metapath: List[Tuple[str, str, str]],
                          k: Optional[int] = None,
                          drop_self_loops: bool = True) -> nx.Graph:
    """
    Undirected NX graph on the start-type's nodes.
    If k is given, apply k-NN sparsification before binarize.
    """
    A = metapath_adjacency(data, metapath)
    if k is not None:
        A = knn_sparsify(A, k=k)
    A = (A > 0).astype(np.uint8)
    A = A.maximum(A.T)
    if drop_self_loops:
        A = A.tolil(); A.setdiag(0); A = A.tocsr(); A.eliminate_zeros()

    start_type = metapath[0][0]
    n = data[start_type].num_nodes
    G = nx.Graph()
    G.add_nodes_from(range(n))
    coo = A.tocoo()
    mask = coo.row < coo.col
    G.add_edges_from(zip(coo.row[mask].tolist(), coo.col[mask].tolist()))
    return G


def build_target_subgraphs(data,
                            cfg: DatasetConfig,
                            k_knn: Optional[Dict[str, int]] = None) -> Dict[str, nx.Graph]:
    """Build target-node-side meta-path subgraphs using the dataset config."""
    k_knn = k_knn or cfg.knn_k or {}
    return {name: metapath_subgraph_nx(data, mp, k=k_knn.get(name))
            for name, mp in cfg.metapaths.items()}


def add_metapath_edges(data, cfg: DatasetConfig,
                        k_knn: Optional[Dict[str, int]] = None):
    """Add meta-path edges to PyG data in-place. Returns data (mutated)."""
    k_knn = k_knn or {}
    for name, mp in cfg.metapaths.items():
        A = metapath_adjacency(data, mp)
        k = k_knn.get(name)
        if k is not None:
            A = knn_sparsify(A, k=k)
        A = (A > 0).astype(np.uint8)
        A = A.maximum(A.T)
        A = A.tolil(); A.setdiag(0); A = A.tocsr(); A.eliminate_zeros()
        coo = A.tocoo()
        ei = torch.tensor(np.vstack([coo.row, coo.col]), dtype=torch.long)
        data[(cfg.target_node, name, cfg.target_node)].edge_index = ei
    return data


# ----------------------------------------------------------------------------
# Backward-compatible DBLP shims
# ----------------------------------------------------------------------------
AUTHOR_METAPATHS = get_config("DBLP").metapaths

def load_dblp(root: str = "/content/dblp_data"):
    return get_config("DBLP").loader(root)

def build_author_subgraphs(data) -> Dict[str, nx.Graph]:
    return build_target_subgraphs(data, get_config("DBLP"))

def add_metapath_edges_to_data(data):
    return add_metapath_edges(data, get_config("DBLP"))


if __name__ == "__main__":
    cfg = get_config("DBLP")
    data = cfg.loader()
    print(data)
    subs = build_target_subgraphs(data, cfg, k_knn={n: 20 for n in cfg.metapaths})
    for name, G in subs.items():
        print(f"{name:6s}: |V|={G.number_of_nodes()}  |E|={G.number_of_edges()}")
