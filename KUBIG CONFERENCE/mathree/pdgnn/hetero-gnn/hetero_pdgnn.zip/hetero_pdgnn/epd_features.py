"""
Per-node EPD feature extraction on a homogeneous (meta-path induced) subgraph.

For each node v in the subgraph:
  1. Take v's k-hop ego-subgraph.
  2. Assign each node u a filter value f(u) = (normalized) shortest-path distance from v.
  3. Compute Extended Persistence Diagram (0D ordinary + 1D extended) via gudhi.
  4. Convert to a persistence image (flattened R x R vector).

The persistence image is the EPD feature for v on this meta-path.
Final node feature = concat of EPDs from all meta-paths.

Computation budget on DBLP:
  ~4000 authors  x  3 meta-paths  ~=  12k EPD computations on small ego-subgraphs.
  Should run in a few minutes single-threaded.

We cache the result to disk keyed by (graph hash, hop, resolution, descriptor).
"""

import os
import hashlib
import pickle
import time
from typing import Dict, List

import numpy as np
import networkx as nx

# TLC-GNN modules (after patches applied)
from sg2dgm.dgformat import Diagram, _Point
from sg2dgm.riccidist2dgm import graph2dgm
import sg2dgm.PersistenceImager as pimg


# ----------------------------------------------------------------------------
# Single-node EPD
# ----------------------------------------------------------------------------
def _assign_distance_filter(G_ego: nx.Graph, source: int, key: str = "min") -> None:
    """Set node[key] = normalized shortest-path distance from source.
       Set edge[key] = max(node_u[key], node_v[key]) so EPD is well-defined."""
    dist = nx.single_source_shortest_path_length(G_ego, source)
    if not dist:
        return
    max_d = max(dist.values()) or 1
    for n in G_ego.nodes():
        G_ego.nodes[n][key] = float(dist.get(n, max_d)) / max_d
    for u, v in G_ego.edges():
        G_ego.edges[u, v][key] = max(G_ego.nodes[u][key], G_ego.nodes[v][key])


def _epd_to_image(dgms, resolution: int) -> np.ndarray:
    """Stack 0D + 1D EPD points and convert to a flattened persistence image."""
    points = []
    for dim_dgm in dgms:
        for p in dim_dgm:
            b, d = float(p.birth), float(p.death)
            if np.isfinite(b) and np.isfinite(d):
                points.append([b, d])
    if not points:
        return np.zeros(resolution * resolution, dtype=np.float32)
    imager = pimg.PersistenceImager(resolution=resolution)
    img = imager.transform(np.array(points))
    return img.flatten().astype(np.float32)


def node_epd_image(G: nx.Graph, v: int,
                    hop: int = 2,
                    resolution: int = 5,
                    key: str = "min") -> np.ndarray:
    """EPD persistence-image feature for node v on graph G (k-hop ego)."""
    if G.degree(v) == 0:
        return np.zeros(resolution * resolution, dtype=np.float32)

    # Build k-hop ego subgraph rooted at v
    nodes = [v] + [x for _, x in nx.bfs_edges(G, v, depth_limit=hop)]
    H = G.subgraph(nodes).copy()
    if H.number_of_nodes() < 2:
        return np.zeros(resolution * resolution, dtype=np.float32)

    _assign_distance_filter(H, source=v, key=key)

    # TLC-GNN's graph2dgm relabels nodes; epd() works on its own copy
    g2d = graph2dgm(H)
    dgms = g2d.epd(H, key=key, pd_flag=False)
    return _epd_to_image(dgms, resolution=resolution)


# ----------------------------------------------------------------------------
# Batch extraction over all author nodes for one meta-path subgraph
# ----------------------------------------------------------------------------
def extract_subgraph_features(G: nx.Graph,
                              hop: int = 2,
                              resolution: int = 5,
                              verbose: bool = True) -> np.ndarray:
    """Return [num_nodes, resolution^2] float32 EPD feature matrix."""
    n = G.number_of_nodes()
    feat = np.zeros((n, resolution * resolution), dtype=np.float32)
    t0 = time.time()
    for v in range(n):
        feat[v] = node_epd_image(G, v, hop=hop, resolution=resolution)
        if verbose and (v + 1) % 500 == 0:
            print(f"  [{v+1}/{n}] elapsed {time.time()-t0:.1f}s")
    return feat


# ----------------------------------------------------------------------------
# Multi-meta-path features with caching
# ----------------------------------------------------------------------------
def _graph_fingerprint(G: nx.Graph) -> str:
    h = hashlib.sha1()
    h.update(str(G.number_of_nodes()).encode())
    h.update(str(G.number_of_edges()).encode())
    # sample 1000 edges by sorted order for stable hash
    edges = sorted(G.edges())[:1000]
    h.update(str(edges).encode())
    return h.hexdigest()[:12]


def build_metapath_epd_features(subgraphs: Dict[str, nx.Graph],
                                 hop: int = 2,
                                 resolution: int = 5,
                                 cache_dir: str = "./epd_cache",
                                 verbose: bool = True) -> np.ndarray:
    """
    For each (meta-path, node) compute EPD image; concat across meta-paths.

    Returns: [num_nodes, num_metapaths * resolution^2] float32
    """
    os.makedirs(cache_dir, exist_ok=True)
    feats: List[np.ndarray] = []
    for name, G in subgraphs.items():
        fp = _graph_fingerprint(G)
        cache_path = os.path.join(cache_dir,
            f"epd_{name}_{fp}_hop{hop}_res{resolution}.npy")
        if os.path.exists(cache_path):
            if verbose:
                print(f"[{name}] cache hit -> {cache_path}")
            feat = np.load(cache_path)
        else:
            if verbose:
                print(f"[{name}] computing EPD on {G.number_of_nodes()} nodes...")
            feat = extract_subgraph_features(G, hop=hop, resolution=resolution,
                                              verbose=verbose)
            np.save(cache_path, feat)
        feats.append(feat)

    return np.concatenate(feats, axis=1).astype(np.float32)
