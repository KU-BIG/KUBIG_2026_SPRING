"""
Colab orchestration script — paste cells into a Colab notebook in order.
Each `# %%` block is one cell.

Assumes:
  - You have run the setup commands in colab_setup.py (git clone TLC-GNN, pip,
    copy dgformat.py + riccidist2dgm.py patches, build sg2dgm).
  - This `hetero_pdgnn/` directory is uploaded to /content/hetero_pdgnn/.
"""

# %% [cell 1] Imports + path setup
import sys, os, time
sys.path.insert(0, "/content/TLC-GNN")        # for sg2dgm.* (after patches)
sys.path.insert(0, "/content")                # so `hetero_pdgnn` package resolves

import torch
import numpy as np
device = "cuda" if torch.cuda.is_available() else "cpu"
print("device:", device)

from hetero_pdgnn.data_metapath import (
    load_dblp, build_author_subgraphs, add_metapath_edges_to_data,
    AUTHOR_METAPATHS,
)
from hetero_pdgnn.epd_features import build_metapath_epd_features
from hetero_pdgnn.train import compare


# %% [cell 2] Load DBLP and inspect
data = load_dblp(root="/content/dblp_data")
print(data)
print("classes:", int(data["author"].y.max().item()) + 1)
print("train/val/test:",
      int(data["author"].train_mask.sum()),
      int(data["author"].val_mask.sum()),
      int(data["author"].test_mask.sum()))


# %% [cell 3] Add meta-path edges (so HANConv can use them)
data = add_metapath_edges_to_data(data)
for et in data.edge_types:
    if et[0] == "author" and et[2] == "author":
        print(f"  {et}: {data[et].edge_index.shape[1]} edges")


# %% [cell 4] Build NX meta-path subgraphs for EPD computation
subs = build_author_subgraphs(data)
for name, G in subs.items():
    print(f"{name:6s}: |V|={G.number_of_nodes()}  |E|={G.number_of_edges()}")


# %% [cell 5] Compute per-node EPD features (cached after first run)
t0 = time.time()
epd_np = build_metapath_epd_features(
    subs,
    hop=2,
    resolution=5,
    cache_dir="/content/epd_cache",
    verbose=True,
)
print(f"EPD features shape: {epd_np.shape}   elapsed {time.time()-t0:.1f}s")
epd_feat = torch.from_numpy(epd_np)


# %% [cell 6] Strip non-meta-path edges so HAN works on meta-path edges only
#            (original HAN paper uses meta-path edges exclusively)
keep_types = [et for et in data.edge_types
              if et[0] == "author" and et[2] == "author" and et[1] in AUTHOR_METAPATHS]
print("HAN will use edge types:", keep_types)

# Build a fresh HeteroData with only the kept edges
from torch_geometric.data import HeteroData
slim = HeteroData()
for nt in data.node_types:
    slim[nt].x = data[nt].x
slim["author"].y = data["author"].y
slim["author"].train_mask = data["author"].train_mask
slim["author"].val_mask   = data["author"].val_mask
slim["author"].test_mask  = data["author"].test_mask
for et in keep_types:
    slim[et].edge_index = data[et].edge_index
print(slim)


# %% [cell 7] Run comparison across seeds
results = compare(
    slim,
    epd_feat,
    hidden_channels=64,
    heads=8,
    seeds=[0, 1, 2, 3, 4],
    device=device,
    verbose=False,
)
print()
print("=" * 50)
print(f"{'Model':<12} {'Test F1 mean':>14} {'std':>8}")
print("-" * 50)
for name, r in results.items():
    print(f"{name:<12} {r['mean']:>14.4f} {r['std']:>8.4f}")
print("=" * 50)
print("Per-seed:", results)
