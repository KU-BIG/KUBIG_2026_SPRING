"""
Dataset-agnostic Colab runner.

Cells separated by `# %%`. Set DATASET_NAME at the top to switch between
"DBLP", "IMDB", "ACM".

Requires the same Colab setup as `run_colab.py` (TLC-GNN cloned + patched
+ sg2dgm built, hetero_pdgnn package available on path).
"""

# %% [cell 1] Imports + dataset selection
import sys, os, time
sys.path.insert(0, "/content/TLC-GNN")
sys.path.insert(0, "/content")

import torch
import numpy as np
device = "cuda" if torch.cuda.is_available() else "cpu"

# ↓ CHANGE THIS LINE TO SWITCH DATASET
DATASET_NAME = "IMDB"     # "DBLP" | "IMDB" | "ACM"

from hetero_pdgnn.datasets import get_config
from hetero_pdgnn.data_metapath import build_target_subgraphs, add_metapath_edges
from hetero_pdgnn.epd_features import build_metapath_epd_features
from hetero_pdgnn.train import compare

cfg = get_config(DATASET_NAME)
print(f"device: {device}   dataset: {cfg.name}   target: {cfg.target_node}")
print(f"metapaths: {list(cfg.metapaths.keys())}")


# %% [cell 2] Load + inspect
data = cfg.loader()
print(data)
print(f"\nnode types: {data.node_types}")
print(f"edge types: {data.edge_types}")
y = data[cfg.target_node].y
print(f"\ntarget '{cfg.target_node}': {y.shape[0]} nodes, "
      f"classes = {int(y.max().item()) + 1}")
for split in ("train_mask", "val_mask", "test_mask"):
    if hasattr(data[cfg.target_node], split):
        n = int(getattr(data[cfg.target_node], split).sum())
        print(f"  {split}: {n}")

# ❗ If the print above shows different edge type names than what's in
#    cfg.metapaths, edit hetero_pdgnn/datasets.py and fix the metapath defs.


# %% [cell 3] Verify metapath edges exist, then add them
missing = []
for name, mp in cfg.metapaths.items():
    for et in mp:
        if et not in data.edge_types:
            missing.append((name, et))
if missing:
    print("⚠️ MISSING edge types — adjust datasets.py:")
    for m in missing: print("  ", m)
    raise RuntimeError("metapath references missing edge type")

data = add_metapath_edges(data, cfg, k_knn=cfg.knn_k)
for et in data.edge_types:
    if et[0] == cfg.target_node and et[2] == cfg.target_node:
        print(f"  {et}: {data[et].edge_index.shape[1]} edges")


# %% [cell 4] Build NX subgraphs (k-NN sparsified) for EPD computation
subs = build_target_subgraphs(data, cfg, k_knn=cfg.knn_k)
for name, G in subs.items():
    n, m = G.number_of_nodes(), G.number_of_edges()
    iso = sum(1 for v in G.nodes if G.degree(v) == 0)
    print(f"{name:6s}: |V|={n}  |E|={m}  avg_deg={2*m/n:.1f}  isolated={iso}")


# %% [cell 5] Compute EPD features (cached)
t0 = time.time()
epd_np = build_metapath_epd_features(
    subs,
    hop=1,
    resolution=5,
    cache_dir=f"/content/epd_cache_{cfg.name}",
    verbose=True,
)
print(f"\nEPD features shape: {epd_np.shape}   elapsed {time.time()-t0:.1f}s")
epd_feat = torch.from_numpy(epd_np)


# %% [cell 6] Build slim HeteroData using k-NN sparsified meta-path edges only
import torch
from torch_geometric.data import HeteroData

slim = HeteroData()
for nt in data.node_types:
    slim[nt].x = data[nt].x
slim[cfg.target_node].y = data[cfg.target_node].y
for split in ("train_mask", "val_mask", "test_mask"):
    if hasattr(data[cfg.target_node], split):
        setattr(slim[cfg.target_node], split, getattr(data[cfg.target_node], split))

# Use k-NN sparsified subgraph edges (apples-to-apples vs EPD)
for name, G in subs.items():
    edges = list(G.edges())
    if edges:
        ei = torch.tensor(edges, dtype=torch.long).t().contiguous()
        ei = torch.cat([ei, ei.flip(0)], dim=1)
    else:
        ei = torch.zeros((2, 0), dtype=torch.long)
    slim[(cfg.target_node, name, cfg.target_node)].edge_index = ei
print(slim)


# %% [cell 7] Compare HAN vs HAN+EPD across seeds
results = compare(
    slim, epd_feat,
    target_node=cfg.target_node,
    hidden_channels=64, heads=8,
    seeds=list(range(10)),
    device=device, verbose=False,
)
print()
print("=" * 50)
print(f"{cfg.name}   {'Model':<10} {'Test F1 mean':>14} {'std':>8}")
print("-" * 50)
for name, r in results.items():
    print(f"      {name:<12} {r['mean']:>14.4f} {r['std']:>8.4f}")
print("=" * 50)
print("Per-seed:", results)
