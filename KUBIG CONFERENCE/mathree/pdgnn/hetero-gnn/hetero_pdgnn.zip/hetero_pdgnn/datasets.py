"""
Dataset configs for multi-dataset experiments.

Each config specifies:
  - loader function (returns a PyG HeteroData)
  - target_node (the type we classify)
  - metapaths (dict of name -> list of edge types)

Verified for:
  - DBLP    via torch_geometric.datasets.DBLP   (already used)
  - IMDB    via torch_geometric.datasets.IMDB
  - ACM     via torch_geometric.datasets.HGBDataset(name='ACM')

NOTE on edge naming conventions:
  PyG's IMDB and DBLP datasets use ("src", "to", "dst") as edge keys.
  HGBDataset (used for ACM) uses ("src", "to", "dst") as well but the node
  type names may differ from the HAN paper conventions. We follow PyG's
  default. If a run fails because the metapath edge type doesn't exist,
  print `data.edge_types` and adjust the metapath list here.
"""

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Tuple
import torch


@dataclass
class DatasetConfig:
    name: str
    target_node: str
    metapaths: Dict[str, List[Tuple[str, str, str]]]
    loader: Callable
    # per-meta-path k for k-NN sparsification (some datasets are denser)
    knn_k: Dict[str, int] = field(default_factory=dict)


# ----------------------------------------------------------------------------
# Loaders
# ----------------------------------------------------------------------------
def _load_dblp(root: str = "/content/dblp_data"):
    from torch_geometric.datasets import DBLP
    data = DBLP(root=root)[0]
    # conference has no features by default → one-hot
    if not hasattr(data["conference"], "x") or data["conference"].x is None:
        n = data["conference"].num_nodes
        data["conference"].x = torch.eye(n)
    return data


def _load_imdb(root: str = "/content/imdb_data"):
    from torch_geometric.datasets import IMDB
    data = IMDB(root=root)[0]
    return data


def _load_acm(root: str = "/content/acm_data"):
    """
    HGBDataset ACM:
      node types: 'paper', 'author', 'subject', 'term'
      task: paper classification (3 classes)
      Labels and splits attached to 'paper' nodes.
    """
    from torch_geometric.datasets import HGBDataset
    data = HGBDataset(root=root, name='ACM')[0]
    # Some node types may lack features → fall back to one-hot identity
    for nt in data.node_types:
        if not hasattr(data[nt], "x") or data[nt].x is None:
            n = data[nt].num_nodes
            data[nt].x = torch.eye(n)
    return data


# ----------------------------------------------------------------------------
# Configs
# ----------------------------------------------------------------------------
DATASETS: Dict[str, DatasetConfig] = {
    "DBLP": DatasetConfig(
        name="DBLP",
        target_node="author",
        metapaths={
            "APA":   [("author", "to", "paper"), ("paper", "to", "author")],
            "APCPA": [("author", "to", "paper"), ("paper", "to", "conference"),
                      ("conference", "to", "paper"), ("paper", "to", "author")],
            "APTPA": [("author", "to", "paper"), ("paper", "to", "term"),
                      ("term", "to", "paper"), ("paper", "to", "author")],
        },
        loader=_load_dblp,
        knn_k={"APA": 20, "APCPA": 20, "APTPA": 20},
    ),
    "IMDB": DatasetConfig(
        name="IMDB",
        target_node="movie",
        metapaths={
            # MAM: movie - actor - movie  (co-actor)
            "MAM": [("movie", "to", "actor"), ("actor", "to", "movie")],
            # MDM: movie - director - movie (same director)
            "MDM": [("movie", "to", "director"), ("director", "to", "movie")],
        },
        loader=_load_imdb,
        knn_k={"MAM": 20, "MDM": 20},
    ),
    "ACM": DatasetConfig(
        name="ACM",
        target_node="paper",
        metapaths={
            # PAP: paper - author - paper (co-author)
            "PAP": [("paper", "to", "author"), ("author", "to", "paper")],
            # PSP: paper - subject - paper (same subject)
            "PSP": [("paper", "to", "subject"), ("subject", "to", "paper")],
        },
        loader=_load_acm,
        knn_k={"PAP": 20, "PSP": 20},
    ),
}


def get_config(name: str) -> DatasetConfig:
    if name not in DATASETS:
        raise KeyError(f"Unknown dataset {name}. Available: {list(DATASETS.keys())}")
    return DATASETS[name]
